package com.rest.process.restConsume.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rest.process.BO.ATMsBO;

@Service
public class ExternalAPIConsumeServiceImpl implements ExternalAPIConsumeService {
	@Autowired
	private RestTemplate restTemplet;
	
	@Override
	public List<ATMsBO> getAtms() throws JsonMappingException, JsonProcessingException {
		List<ATMsBO> jsonList = new ArrayList<>();
		try {
		String allJSON = restTemplet.getForObject("https://www.ing.nl/api/locator/atms/", String.class);
		// Using String substring method because of given URI exposed json response is invalid, correcting json respose with invalid values  
		allJSON = allJSON.substring(5, allJSON.length());

		ObjectMapper mapper = new ObjectMapper();
		jsonList = Arrays.asList(mapper.readValue(allJSON, ATMsBO[].class));
	
		}catch (Exception e) {
			System.out.println(e);
		}
		return jsonList;
	}

}
